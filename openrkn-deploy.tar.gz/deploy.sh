#!/bin/sh
set -e

echo "=========================================================="
echo "           УСТАНОВКА И РАЗВЕРТЫВАНИЕ OpenRKN              "
echo "              OpenWrt 25 (x86_64 / ARM)                   "
echo "=========================================================="

fetch_url() {
    url="$1"
    dest="$2"
    if command -v curl >/dev/null 2>&1; then
        curl -fsSL -o "$dest" "$url"
    elif command -v wget >/dev/null 2>&1; then
        wget -q -O "$dest" "$url"
    elif command -v uclient-fetch >/dev/null 2>&1; then
        uclient-fetch -q -O "$dest" "$url"
    else
        echo "[!] Ошибка: не найден инструмент скачивания (curl/wget/uclient-fetch)." >&2
        return 1
    fi
}

ARCH=$(uname -m)
case "$ARCH" in
    x86_64|amd64)
        FLUX_BIN="openflux-linux-amd64"
        ZAPRET_DIR="linux-x86_64"
        ;;
    aarch64|arm64)
        echo "[!] Архитектура $ARCH: экспериментальная поддержка (тестировалось на x86_64)."
        FLUX_BIN="openflux-linux-arm64"
        ZAPRET_DIR="linux-arm64"
        ;;
    armv7l|arm)
        echo "[!] Архитектура $ARCH: экспериментальная поддержка (тестировалось на x86_64)."
        FLUX_BIN="openflux-linux-arm"
        ZAPRET_DIR="linux-arm"
        ;;
    *)
        echo "[!] Неизвестная архитектура: $ARCH. По умолчанию x86_64."
        FLUX_BIN="openflux-linux-amd64"
        ZAPRET_DIR="linux-x86_64"
        ;;
esac

echo "[1/7] Проверка и установка пакетов..."
if command -v apk >/dev/null 2>&1; then
    echo "  -> Обнаружен apk (OpenWrt 24.10+ / 25.x)..."
    apk update 2>/dev/null || true
    apk add rpcd ubus uci libubox jshn firewall4 kmod-nft-queue kmod-nfnetlink-queue ca-bundle curl tar gzip 2>/dev/null || \
    apk add rpcd ubus uci libubox jshn firewall4 kmod-nft-queue kmod-nfnetlink-queue ca-certificates curl tar gzip 2>/dev/null || true
elif command -v opkg >/dev/null 2>&1; then
    echo "  -> Обнаружен opkg (OpenWrt legacy)..."
    opkg update 2>/dev/null || true
    opkg install rpcd ubus uci libubox jshn firewall4 kmod-nft-queue kmod-nfnetlink-queue ca-bundle curl tar gzip coreutils-od 2>/dev/null || true
elif command -v apt-get >/dev/null 2>&1; then
    echo "  -> Обнаружен apt (Debian/Ubuntu/Armbian)..."
    apt-get update -y 2>/dev/null || true
    apt-get install -y curl tar gzip ca-certificates 2>/dev/null || true
else
    echo "  -> Пакетный менеджер не найден или пакеты встроены в прошивку, продолжаем..."
fi

echo "[2/7] Создание системного пользователя openrkn (UID 453)..."
grep -q '^openrkn:' /etc/passwd 2>/dev/null || echo 'openrkn:x:453:453:openrkn:/var/run/openrkn:/bin/false' >> /etc/passwd 2>/dev/null || true
grep -q '^openrkn:' /etc/group 2>/dev/null || echo 'openrkn:x:453:' >> /etc/group 2>/dev/null || true

echo "[3/7] Подготовка каталогов..."
mkdir -p /opt/openrkn/bin /etc/openrkn /etc/openrkn/profiles /var/run/openrkn /www/openrkn
chown -R openrkn:openrkn /var/run/openrkn /etc/openrkn/profiles 2>/dev/null || true

echo "[4/7] Загрузка бинарников openflux и zapret ($ARCH)..."
if [ ! -x /opt/openrkn/bin/openflux ]; then
    echo "  -> Скачивание openflux ($FLUX_BIN)..."
    fetch_url "https://github.com/p1neappleXpress/OpenFlux/releases/download/v0.3.0/$FLUX_BIN" /opt/openrkn/bin/openflux
    chmod 755 /opt/openrkn/bin/openflux
fi

if [ ! -x /opt/openrkn/bin/nfqws ]; then
    echo "  -> Скачивание nfqws (zapret)..."
    fetch_url "https://github.com/bol-van/zapret/releases/download/v72.13/zapret-v72.13.tar.gz" /tmp/zapret.tar.gz
    tar -xzf /tmp/zapret.tar.gz -C /tmp
    NFQ_SRC="/tmp/zapret-v72.13/binaries/$ZAPRET_DIR/nfqws"
    if [ ! -f "$NFQ_SRC" ]; then
        NFQ_SRC=$(find /tmp/zapret-*/binaries -type f -name nfqws 2>/dev/null | grep "$ZAPRET_DIR" | head -n 1)
    fi
    if [ ! -f "$NFQ_SRC" ]; then
        NFQ_SRC=$(find /tmp/zapret-*/binaries -type f -name nfqws 2>/dev/null | head -n 1)
    fi
    if [ -f "$NFQ_SRC" ]; then
        cp "$NFQ_SRC" /opt/openrkn/bin/nfqws
        chmod 755 /opt/openrkn/bin/nfqws
    else
        echo "[!] Ошибка: не удалось найти бинарник nfqws для $ZAPRET_DIR" >&2
        exit 1
    fi
    rm -rf /tmp/zapret.tar.gz /tmp/zapret-*
fi

echo "[5/7] Копирование файлов пакета OpenRKN..."
SCRIPT_DIR=$(dirname "$0")
if [ -d "$SCRIPT_DIR/files" ]; then
    cp -r "$SCRIPT_DIR/files"/* /
else
    echo "  -> Скачивание дерева файлов пакета из GitHub..."
    fetch_url "https://raw.githubusercontent.com/DJEBAN228/OpenRKN-Manager/main/openrkn-deploy.tar.gz" /tmp/openrkn-deploy.tar.gz
    tar -xzf /tmp/openrkn-deploy.tar.gz -C /tmp
    cp -r /tmp/files/* /
    rm -rf /tmp/openrkn-deploy.tar.gz /tmp/files
fi

chmod 755 /etc/init.d/openrkn /usr/libexec/rpcd/openrkn /usr/libexec/openrkn/* 2>/dev/null || true

# Генерация ключа шифрования если отсутствует
if [ ! -f /etc/openrkn/secret.key ]; then
    echo "  -> Генерация ключа шифрования AES-256..."
    if command -v od >/dev/null 2>&1; then
        head -c 32 /dev/urandom | od -An -tx1 | tr -d ' \n' > /etc/openrkn/secret.key
    elif command -v hexdump >/dev/null 2>&1; then
        head -c 32 /dev/urandom | hexdump -v -e '1/1 "%02x"' > /etc/openrkn/secret.key
    else
        head -c 32 /dev/urandom | tr -dc 'a-f0-9' | head -c 64 > /etc/openrkn/secret.key
    fi
    chmod 600 /etc/openrkn/secret.key
fi

# Дефолтный exit.conf
if [ ! -f /etc/openrkn/exit.conf ]; then
    cp /etc/openrkn/exit.conf.example /etc/openrkn/exit.conf 2>/dev/null || true
fi

echo "[6/7] Настройка веб-сервера..."
if command -v uci >/dev/null 2>&1; then
    uci -q get uhttpd.openrkn >/dev/null || {
        uci set uhttpd.openrkn=uhttpd
        uci set uhttpd.openrkn.listen_http='0.0.0.0:7788'
        uci set uhttpd.openrkn.home='/www'
        uci set uhttpd.openrkn.cgi_prefix='/cgi-bin'
        uci commit uhttpd
        [ -x /etc/init.d/uhttpd ] && /etc/init.d/uhttpd restart 2>/dev/null || true
    }
fi

echo "[7/7] Запуск служб..."
[ -x /etc/init.d/rpcd ] && /etc/init.d/rpcd restart 2>/dev/null || true
if command -v fw4 >/dev/null 2>&1; then
    fw4 reload 2>/dev/null || true
fi
if [ -x /etc/init.d/openrkn ]; then
    /etc/init.d/openrkn enable 2>/dev/null || true
    /etc/init.d/openrkn restart 2>/dev/null || true
fi

LAN_IP="192.168.1.1"
if command -v uci >/dev/null 2>&1; then
    LAN_IP=$(uci -q get network.lan.ipaddr || echo "192.168.1.1")
fi

echo ""
echo "=========================================================="
echo "             OpenRKN УСПЕШНО РАЗВЕРНУТ!                   "
echo "=========================================================="
echo "  Панель управления доступна:"
echo "  👉 http://$LAN_IP/openrkn/       (основной порт LuCI 80)"
echo "  👉 http://$LAN_IP:7788/openrkn/  (выделенный порт OpenRKN)"
echo "=========================================================="
